package cn.sharesdk.demo.sensor;

/**
 * Created by yjin on 2017/5/17.
 */

/**
 * 摇一摇接口类
 */

public interface OnSharkeShotListener {
	public void onShark();
}
