package cn.sharesdk.demo.ui;

/**
 * Created by yjin on 2017/5/16.
 */

public interface CallBackShotImageView {
	public void onRefresh(String url);
}
