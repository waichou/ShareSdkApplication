package cn.sharesdk.demo.manager.ui;

import cn.sharesdk.demo.activitys.SharePlatformTypeActivity;
import cn.sharesdk.demo.manager.BasePresenter;

/**
 * Created by yjin on 2017/5/17.
 */

public class SharePlatformPresenter extends BasePresenter<SharePlatformTypeActivity> {

}
