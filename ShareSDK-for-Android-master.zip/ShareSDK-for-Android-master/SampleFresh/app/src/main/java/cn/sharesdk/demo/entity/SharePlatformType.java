package cn.sharesdk.demo.entity;

/**
 * Created by yjin on 2017/5/11.
 */

public interface SharePlatformType {
	public final static int DIRECT_SHARE_PLAT = 1;
	public final static int TITLE_SHARE_PLAT = 2;
	public final static int FOREIGN_SHARE_PLAT = 3;
}
