package cn.sharesdk.demo.platform.tencent.weibo;

/**
 * Created by yjin on 2017/6/22.
 */

public class WeiboShare {
}
