package cn.sharesdk.demo.entity;

/**
 * Created by yjin on 2017/5/10.
 */

public class OutBaseEntity implements BaseEntity {

}
